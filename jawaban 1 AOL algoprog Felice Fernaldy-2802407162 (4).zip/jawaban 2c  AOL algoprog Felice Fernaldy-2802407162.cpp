#include <stdio.h>
#include <stdlib.h>
#include <string.h>

const int MAX_ROWS = 1000;
const int MAX_COLS = 100;
const int MAX_LINE_LENGTH = 1024;

typedef struct {
    char location[50];
    char city[50];
    int price;
    int rooms;
    int bathrooms;
    int carpark;
    char type[50];
    char furnish[50];
} Property;

void readCSV(const char *filename, Property properties[], int *rowCount) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Unable to open file");
        exit(EXIT_FAILURE);
    }

    char line[MAX_LINE_LENGTH];
    *rowCount = 0;

    fgets(line, sizeof(line), file);

    while (fgets(line, sizeof(line), file) && *rowCount < MAX_ROWS) {
        sscanf(line, "%[^,],%[^,],%d,%d,%d,%d,%[^,],%s",
               properties[*rowCount].location,
               properties[*rowCount].city,
               &properties[*rowCount].price,
               &properties[*rowCount].rooms,
               &properties[*rowCount].bathrooms,
               &properties[*rowCount].carpark,
               properties[*rowCount].type,
               properties[*rowCount].furnish);
        (*rowCount)++;
    }

    fclose(file);
}

int compareAscending(const void *a, const void *b) {
    Property *propA = (Property *)a;
    Property *propB = (Property *)b;
    return propA->rooms - propB->rooms;
}

int compareDescending(const void *a, const void *b) {
    Property *propA = (Property *)a;
    Property *propB = (Property *)b;
    return propB->rooms - propA->rooms;
}

void sortData(Property properties[], int rowCount, const char *order) {
    if (strcmp(order, "asc") == 0) {
        qsort(properties, rowCount, sizeof(Property), compareAscending);
    } else if (strcmp(order, "desc") == 0) {
        qsort(properties, rowCount, sizeof(Property), compareDescending);
    }
}

void displayData(Property properties[], int rowCount) {
    printf("%-20s %-15s %-10s %-10s %-10s %-10s %-15s %-10s\n", 
           "Location", "City", "Price", "Rooms", "Bathrooms", "Carpark", "Type", "Furnish");
    for (int i = 0; i < rowCount && i < 10; i++) {
        printf("%-20s %-15s %-10d %-10d %-10d %-10d %-15s %-10s\n", 
               properties[i].location, properties[i].city, properties[i].price, properties[i].rooms, 
               properties[i].bathrooms, properties[i].carpark, properties[i].type, properties[i].furnish);
    }
}

int main() {
    Property properties[1000];
    int rowCount;
    char order[10];
    int choice;

    readCSV("File.csv", properties, &rowCount);

    while (1) {
        printf("What do you want to do?\n");
        printf("1. Display data\n");
        printf("2. Search Data\n");
        printf("3. Sort Data\n");
        printf("4. Export Data\n");
        printf("5. Exit\n");
        printf("Your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("\nDisplaying data:\n\n");
                displayData(properties, rowCount);
                break;
            case 2:
                printf("Search functionality is not implemented yet.\n");
                break;
            case 3:
                printf("Choose column: Rooms\n");
                printf("Sort ascending or descending? (asc/desc): ");
                scanf("%s", order);

                sortData(properties, rowCount, order);

                printf("\nData found. Detail of data:\n\n");
                displayData(properties, rowCount);
                break;
            case 4:
                printf("Export functionality is not implemented yet.\n");
                break;
            case 5:
                printf("Exiting program.\n");
                exit(0);
            default:
                printf("Invalid choice. Please try again.\n");
        }

        printf("\n");
    }

    return 0;
}

