#include <stdio.h>
#include <string.h>

void reverseAndInverse(char *str) {
    int len = strlen(str);
    char result[len + 1]; 
    
   
    for (int i = 0; i < len; i++) {
        char current = str[len - 1 - i];
        
        
        if (current >= 'a' && current <= 'z') { 
            result[i] = current - 32; 
        } 
        else if (current >= 'A' && current <= 'Z') { 
            result[i] = current + 32; 
        } 
        else {
            result[i] = current; 
        }
    }
    result[len] = '\0'; 
    
    printf("Modified String: %s\n", result);
}

int main() {
    char input[101]; 
    printf("Enter a string (max 100 characters): ");
    scanf("%100s", input); 
    
    reverseAndInverse(input);

    return 0;
}
