#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct {
    char location[100];
    char city[100];
    int price;
    int rooms;
    int bathroom;
    int carpark;
    char type[100];
    char furnish[100];
} Property;

void trim(char *str) {
    int i = strlen(str) - 1;
    while (i >= 0 && (str[i] == '\n' || str[i] == '\r' || str[i] == ' ')) {
        str[i--] = '\0';
    }

    int start = 0;
    while (str[start] == ' ') {
        start++;
    }
    if (start > 0) {
        memmove(str, str + start, strlen(str) - start + 1);
    }
}

Property *loadDataFromFile(const char *filename, int *totalRows) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        printf("Error: Cannot open file %s\n", filename);
        exit(1);
    }

    int capacity = 100; 
    *totalRows = 0;
    Property *data = (Property *)malloc(capacity * sizeof(Property));

    char buffer[512];
    fgets(buffer, sizeof(buffer), file); 

    while (fgets(buffer, sizeof(buffer), file)) {
        if (*totalRows >= capacity) {
            capacity *= 2;
            data = (Property *)realloc(data, capacity * sizeof(Property));
        }

        trim(buffer);
        sscanf(buffer, "%99[^,],%99[^,],%d,%d,%d,%d,%99[^,],%99[^\n]",
               data[*totalRows].location, data[*totalRows].city, &data[*totalRows].price,
               &data[*totalRows].rooms, &data[*totalRows].bathroom, &data[*totalRows].carpark,
               data[*totalRows].type, data[*totalRows].furnish);
        (*totalRows)++;
    }

    printf("Total data rows loaded: %d\n", *totalRows); 
    fclose(file);
    return data;
}

//menampilkan semua data
void displayData(Property *data, int totalRows) {
    printf("\n%-15s %-15s %-8s %-6s %-10s %-8s %-15s %-10s\n",
           "Location", "City", "Price", "Rooms", "Bathroom", "Carpark", "Type", "Furnish");
    for (int i = 0; i < totalRows; i++) {
        printf("%-15s %-15s %-8d %-6d %-10d %-8d %-15s %-10s\n",
               data[i].location, data[i].city, data[i].price,
               data[i].rooms, data[i].bathroom, data[i].carpark,
               data[i].type, data[i].furnish);
    }
}

// Fungsi mencari data berdasarkan kolom dan nilai
void searchData(Property *data, int totalRows) {
    char column[100], query[100];
    printf("Choose column (Location/City): ");
    scanf(" %[^\n]", column);
    trim(column);

    printf("What data do you want to find? ");
    scanf(" %[^\n]", query);
    trim(query);

    int found = 0;
    printf("\n%-15s %-15s %-8s %-6s %-10s %-8s %-15s %-10s\n",
           "Location", "City", "Price", "Rooms", "Bathroom", "Carpark", "Type", "Furnish");

    for (int i = 0; i < totalRows; i++) {
        if ((strcmp(column, "Location") == 0 && strcmp(data[i].location, query) == 0) ||
            (strcmp(column, "City") == 0 && strcmp(data[i].city, query) == 0)) {
            printf("%-15s %-15s %-8d %-6d %-10d %-8d %-15s %-10s\n",
                   data[i].location, data[i].city, data[i].price,
                   data[i].rooms, data[i].bathroom, data[i].carpark,
                   data[i].type, data[i].furnish);
            found = 1;
        }
    }

    if (!found) {
        printf("Data not found!\n");
    }
}

int main() {
    int choice, totalRows;
    Property *data = loadDataFromFile("File.csv", &totalRows);

    do {
        printf("\nWhat do you want to do?\n");
        printf("1. Display data\n");
        printf("2. Search Data\n");
        printf("3. Sort Data\n");
        printf("4. Export Data\n");
        printf("5. Exit\n");
        printf("Your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                displayData(data, totalRows);
                break;
            case 2:
                searchData(data, totalRows);
                break;
            case 3:
                printf("Sorting data is not implemented yet.\n");
                break;
            case 4:
                printf("Exporting data is not implemented yet.\n");
                break;
            case 5:
                printf("Exiting...\n");
                break;
            default:
                printf("Invalid choice! Try again.\n");
        }
    } while (choice != 5);

    free(data);
    return 0;
}

