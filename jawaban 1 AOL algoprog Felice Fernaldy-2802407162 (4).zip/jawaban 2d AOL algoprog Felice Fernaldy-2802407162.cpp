#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char data[1000][10][100]; 
int rows = 0, cols = 0;

void load_csv(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        printf("Failed to open file %s!\n", filename);
        exit(1);
    }

    char line[1024];
    rows = 0;

    while (fgets(line, sizeof(line), file)) {
        int col = 0;
        char *token = strtok(line, ",\n");
        while (token && col < 10) {
            strcpy(data[rows][col++], token);
            token = strtok(NULL, ",\n");
        }
        if (cols == 0) cols = col; 
        rows++;
    }
    fclose(file);
}

void display_data() {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%-15s ", data[i][j]);
        }
        printf("\n");
    }
}

void export_data(const char *filename) {
    FILE *file = fopen(filename, "w");
    if (!file) {
        printf("Failed to create file %s!\n", filename);
        return;
    }
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            fprintf(file, "%s%s", data[i][j], (j == cols - 1) ? "\n" : ",");
        }
    }
    fclose(file);
    printf("Data successfully written to file %s.csv!\n", filename);
}

int main() {
    char filename[50] = "File.csv"; 
    load_csv(filename);

    while (1) {
        printf("\nWhat do you want to do?\n");
        printf("1. Display data\n");
        printf("2. Search Data\n");
        printf("3. Sort Data\n");
        printf("4. Export Data\n");
        printf("5. Exit\n");
        printf("Your choice: ");

        int choice;
        scanf("%d", &choice);

        if (choice == 1) {
            display_data();
        } else if (choice == 4) {
            char export_filename[50];
            printf("File name: ");
            scanf("%s", export_filename);
            export_data(export_filename);
        } else if (choice == 5) {
            printf("Exiting...\n");
            break;
        } else {
            printf("Invalid choice! Try again.\n");
        }
    }
    return 0;
}

