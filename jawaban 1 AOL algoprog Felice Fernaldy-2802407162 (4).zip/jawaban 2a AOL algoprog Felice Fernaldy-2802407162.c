#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void truncateString(char *str, int maxLength) {
    if (strlen(str) > maxLength) {
        str[maxLength] = '\0';
    }
}

void displayDataFromCSV(const char *filename, int numRows) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        printf("Error: Could not open file %s\n", filename);
        return;
    }
    char line[256];
    int rowCount = 0;
    if (fgets(line, sizeof(line), file)) {
        printf("\n%-20s %-15s %-10s %-10s %-10s %-10s %-15s %-12s\n", 
               "Location", "City", "Price", "Rooms", "Bathrooms", "Carpark", "Type", "Furnish");
        printf("==============================================================================================\n");
    } else {
        printf("Error: File is empty or corrupted.\n");
        fclose(file);
        return;
    }
    while (fgets(line, sizeof(line), file)) {
        char location[50], city[50], type[20], furnish[20];
        int price, rooms, bathrooms, carpark;

        if (sscanf(line, "%49[^,],%49[^,],%d,%d,%d,%d,%19[^,],%19s",
                   location, city, &price, &rooms, &bathrooms, &carpark, type, furnish) == 8) {
            truncateString(location, 20);
            truncateString(city, 15);
            truncateString(type, 15);
            truncateString(furnish, 12);
            printf("%-20s %-15s %-10d %-10d %-10d %-10d %-15s %-12s\n",
                   location, city, price, rooms, bathrooms, carpark, type, furnish);
            rowCount++;
        }
        if (rowCount == numRows) break;
    }
    fclose(file);
    if (rowCount == 0) {
        printf("No data available.\n");
    }
}

int main() {
    const char *filename = "File.csv";
    while (1) {
        int choice;
        printf("\nWhat do you want to do?\n");
        printf("1. Display data\n");
        printf("2. Exit\n");
        printf("Your choice: ");
        scanf("%d", &choice);
        if (choice == 1) {
            int numRows;
            printf("Number of rows to display: ");
            scanf("%d", &numRows);
            if (numRows <= 0) {
                printf("Error: Number of rows must be greater than 0.\n");
                continue;
            }
            displayDataFromCSV(filename, numRows);
        } else if (choice == 2) {
            break;
        } else {
            printf("Invalid choice. Please try again.\n");
        }
    }
    return 0;
}
